from django.urls import path
from .views import Index,DashboardPage, Register, Login, logoutuser

urlpatterns = [
    path('', Index, name="index"),
    path('dashboard/', DashboardPage, name="dashboard-page"),
    path('register/', Register, name="register-page"),
    path('login/', Login, name="login-page"),
    path('logout/', logoutuser, name='logout'),
]